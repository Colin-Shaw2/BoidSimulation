# Unzip into a file then run the exe

Unfortunately this will only work on windows x64 but who runs x86 anyways?